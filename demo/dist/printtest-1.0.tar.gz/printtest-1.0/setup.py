from setuptools import setup
setup(name='printtest',
      version='1.0',
      py_modules=['printtest'],
      )