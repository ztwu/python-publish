def test():
    print('print test')