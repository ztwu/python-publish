def print1() :
    print("hello world 1")