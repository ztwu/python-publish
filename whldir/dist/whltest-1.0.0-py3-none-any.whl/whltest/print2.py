def print2() :
    print("hello world 2")